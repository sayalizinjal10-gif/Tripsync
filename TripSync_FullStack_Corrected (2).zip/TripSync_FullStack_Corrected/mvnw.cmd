@echo off
set "MAVEN_CMD=C:\Users\Khushi\.vscode\extensions\oracle.oracle-java-27.0.0\nbcode\java\maven\bin\mvn.cmd"
if exist "%MAVEN_CMD%" (
    "%MAVEN_CMD%" -f "%~dp0TripSync_FullStack\pom.xml" %*
) else (
    mvn -f "%~dp0TripSync_FullStack\pom.xml" %*
)
