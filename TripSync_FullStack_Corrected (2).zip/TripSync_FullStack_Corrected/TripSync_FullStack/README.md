# TripSync – Group Trip Planning Website

**Stack:** Java 17, Spring Boot, Hibernate/JPA, MySQL, Thymeleaf, Spring Security, REST API, Bootstrap/CSS and Chart.js.

## Setup
1. Install JDK 17+, Maven 3.8+ and MySQL 8+.
2. Open `src/main/resources/application.properties` and replace `CHANGE_ME` with your MySQL root password.
3. Optional: run `CREATE DATABASE tripsync_db;` in MySQL. The URL also creates it automatically if permissions allow.
4. Open a terminal in this project folder and run `mvn spring-boot:run`.
5. Visit `http://localhost:8080`.

## Demo login
Username: `admin`  
Password: `admin123`

The demo user is stored in memory for a college demo. Do not use these credentials in production.

## REST API (login required)
- `GET /api/trips` — list trips
- `POST /api/trips` — create a trip: `{"name":"Goa Getaway","destination":"Goa","startDate":"2026-11-10","endDate":"2026-11-13","members":4}`
- `GET /api/trips/{id}/destinations` and `POST /api/trips/{id}/destinations` — list/add suggestions
- `POST /api/destinations/{id}/vote` — vote on a destination
- `GET/POST /api/trips/{id}/itinerary` — view/add itinerary items
- `GET/POST /api/trips/{id}/expenses` — view/add expenses
- `GET /api/trips/{id}/summary` — total expense and equal share

JPA entities map to MySQL tables automatically (`ddl-auto=update`). The interface uses Thymeleaf templates and Chart.js to display the expense breakdown.
