package com.tripsync.repository;

import com.tripsync.model.Trip;
import com.tripsync.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TripRepository extends JpaRepository<Trip, Long> {
    List<Trip> findByCreatedByOrderByStartDateDesc(User user);
    List<Trip> findAllByOrderByStartDateDesc();

    @Query("SELECT t FROM Trip t WHERE LOWER(t.name) LIKE LOWER(CONCAT('%', :query, '%')) OR LOWER(t.destination) LIKE LOWER(CONCAT('%', :query, '%')) ORDER BY t.startDate DESC")
    List<Trip> searchTrips(@Param("query") String query);
}
