package com.tripsync.service;

import com.tripsync.model.ItineraryItem;
import com.tripsync.model.Trip;
import com.tripsync.repository.ItineraryItemRepository;
import com.tripsync.repository.TripRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.*;

/**
 * Service managing day-by-day itinerary activities, timelines, and groupings.
 */
@Service
public class ItineraryService {

    private final ItineraryItemRepository itineraryRepository;
    private final TripRepository tripRepository;

    public ItineraryService(ItineraryItemRepository itineraryRepository, TripRepository tripRepository) {
        this.itineraryRepository = itineraryRepository;
        this.tripRepository = tripRepository;
    }

    public List<ItineraryItem> getItineraryForTrip(Long tripId) {
        return itineraryRepository.findByTripIdOrderByActivityDateAscActivityTimeAsc(tripId);
    }

    /**
     * Groups itinerary items chronologically by date.
     */
    public Map<LocalDate, List<ItineraryItem>> getGroupedItinerary(Long tripId) {
        List<ItineraryItem> items = getItineraryForTrip(tripId);
        Map<LocalDate, List<ItineraryItem>> grouped = new TreeMap<>();
        for (ItineraryItem item : items) {
            grouped.computeIfAbsent(item.getActivityDate(), k -> new ArrayList<>()).add(item);
        }
        return grouped;
    }

    @Transactional
    public ItineraryItem addItineraryItem(Long tripId, ItineraryItem item) {
        Trip trip = tripRepository.findById(tripId)
                .orElseThrow(() -> new IllegalArgumentException("Trip not found with ID: " + tripId));

        if (item.getActivityDate() == null) {
            throw new IllegalArgumentException("Activity date is required.");
        }

        item.setTrip(trip);
        return itineraryRepository.save(item);
    }

    @Transactional
    public void deleteItineraryItem(Long itemId) {
        itineraryRepository.deleteById(itemId);
    }

    public Optional<ItineraryItem> getItemById(Long itemId) {
        return itineraryRepository.findById(itemId);
    }
}
