package com.tripsync.dto;

import java.math.BigDecimal;

/**
 * DTO representing an optimized direct settlement: "fromMember" pays "amount" to "toMember".
 */
public class SettlementDto {
    private String fromMember;
    private String toMember;
    private BigDecimal amount;

    public SettlementDto() {
    }

    public SettlementDto(String fromMember, String toMember, BigDecimal amount) {
        this.fromMember = fromMember;
        this.toMember = toMember;
        this.amount = amount;
    }

    public String getFromMember() {
        return fromMember;
    }

    public void setFromMember(String fromMember) {
        this.fromMember = fromMember;
    }

    public String getToMember() {
        return toMember;
    }

    public void setToMember(String toMember) {
        this.toMember = toMember;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }
}
