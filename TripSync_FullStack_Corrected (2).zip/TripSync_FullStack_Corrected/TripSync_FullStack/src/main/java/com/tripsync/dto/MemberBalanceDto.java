package com.tripsync.dto;

import java.math.BigDecimal;

/**
 * DTO tracking a single member's financial summary in a group trip.
 */
public class MemberBalanceDto {
    private String memberName;
    private BigDecimal totalPaid;
    private BigDecimal fairShare;
    private BigDecimal netBalance; // positive = gets back, negative = owes

    public MemberBalanceDto() {
    }

    public MemberBalanceDto(String memberName, BigDecimal totalPaid, BigDecimal fairShare, BigDecimal netBalance) {
        this.memberName = memberName;
        this.totalPaid = totalPaid;
        this.fairShare = fairShare;
        this.netBalance = netBalance;
    }

    public String getMemberName() {
        return memberName;
    }

    public void setMemberName(String memberName) {
        this.memberName = memberName;
    }

    public BigDecimal getTotalPaid() {
        return totalPaid;
    }

    public void setTotalPaid(BigDecimal totalPaid) {
        this.totalPaid = totalPaid;
    }

    public BigDecimal getFairShare() {
        return fairShare;
    }

    public void setFairShare(BigDecimal fairShare) {
        this.fairShare = fairShare;
    }

    public BigDecimal getNetBalance() {
        return netBalance;
    }

    public void setNetBalance(BigDecimal netBalance) {
        this.netBalance = netBalance;
    }

    public boolean isOwedMoney() {
        return netBalance != null && netBalance.compareTo(BigDecimal.ZERO) > 0;
    }

    public boolean owesMoney() {
        return netBalance != null && netBalance.compareTo(BigDecimal.ZERO) < 0;
    }

    public boolean isSettled() {
        return netBalance != null && netBalance.compareTo(BigDecimal.ZERO) == 0;
    }
}
