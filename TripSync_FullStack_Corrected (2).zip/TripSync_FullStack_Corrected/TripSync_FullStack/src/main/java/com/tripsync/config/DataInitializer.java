package com.tripsync.config;

import com.tripsync.model.*;
import com.tripsync.repository.*;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Initializes default demo data (demo user and sample trip) upon application startup.
 * Ensures the project works immediately for viva presentation and testing without manual seeding.
 */
@Component
public class DataInitializer implements CommandLineRunner {

    private final UserRepository userRepository;
    private final TripRepository tripRepository;
    private final TripMemberRepository memberRepository;
    private final DestinationRepository destinationRepository;
    private final ItineraryItemRepository itineraryRepository;
    private final ExpenseRepository expenseRepository;
    private final PasswordEncoder passwordEncoder;

    public DataInitializer(UserRepository userRepository,
                           TripRepository tripRepository,
                           TripMemberRepository memberRepository,
                           DestinationRepository destinationRepository,
                           ItineraryItemRepository itineraryRepository,
                           ExpenseRepository expenseRepository,
                           PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.tripRepository = tripRepository;
        this.memberRepository = memberRepository;
        this.destinationRepository = destinationRepository;
        this.itineraryRepository = itineraryRepository;
        this.expenseRepository = expenseRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    @Transactional
    public void run(String... args) {
        // 1. Create demo admin user if not exists
        User admin = userRepository.findByUsername("admin").orElseGet(() -> {
            User u = new User(
                    "admin",
                    "admin@tripsync.com",
                    passwordEncoder.encode("admin123"),
                    "TripSync Admin",
                    "ROLE_USER"
            );
            return userRepository.save(u);
        });

        // 2. Create sample trip if no trips exist
        if (tripRepository.count() == 0) {
            LocalDate today = LocalDate.now();
            Trip trip = new Trip(
                    "Goa Adventure Getaway",
                    "Goa, India",
                    today.plusDays(5),
                    today.plusDays(9),
                    "Annual college friends getaway to explore north Goa beaches, historic forts, water sports, and beachside dining.",
                    "Flight",
                    "Flight: Mumbai T2 -> Goa Dabolim (08:30 AM). Stay: Calangute Bay Palms Resort. Local transport: Two rented SUVs.",
                    new BigDecimal("30000.00")
            );
            trip.setStatus("CONFIRMED");
            trip.setCreatedBy(admin);
            Trip savedTrip = tripRepository.save(trip);

            // Group Members
            TripMember m1 = memberRepository.save(new TripMember("TripSync Admin", "admin@tripsync.com", "Organizer", savedTrip));
            TripMember m2 = memberRepository.save(new TripMember("Rahul Sharma", "rahul@example.com", "Member", savedTrip));
            TripMember m3 = memberRepository.save(new TripMember("Pooja Patel", "pooja@example.com", "Member", savedTrip));
            TripMember m4 = memberRepository.save(new TripMember("Amit Verma", "amit@example.com", "Member", savedTrip));

            // Suggested Destinations with Votes
            Destination d1 = new Destination("Baga Beach & Water Sports", "Jet skiing, parasailing, and beach shacks", new BigDecimal("4000.00"), savedTrip);
            d1.setVotes(4);
            destinationRepository.save(d1);

            Destination d2 = new Destination("Dudhsagar Waterfalls Trek", "Scenic train view and jeep safari", new BigDecimal("3500.00"), savedTrip);
            d2.setVotes(3);
            destinationRepository.save(d2);

            Destination d3 = new Destination("Fort Aguada & Lighthouse", "Portuguese fort overlooking Sinquerim beach sunset", new BigDecimal("500.00"), savedTrip);
            d3.setVotes(2);
            destinationRepository.save(d3);

            // Daily Itinerary
            itineraryRepository.save(new ItineraryItem(
                    "Airport Arrival & Resort Check-in",
                    today.plusDays(5),
                    "10:30 AM",
                    "Calangute Bay Palms Resort",
                    "Travel",
                    "Check-in, unpack bags, and group briefing by the pool.",
                    savedTrip
            ));

            itineraryRepository.save(new ItineraryItem(
                    "Sunset Walk & Welcome Dinner",
                    today.plusDays(5),
                    "06:30 PM",
                    "Britto's Shack, Baga",
                    "Food",
                    "Enjoy seaside seafood, live music, and trip orientation.",
                    savedTrip
            ));

            itineraryRepository.save(new ItineraryItem(
                    "Water Sports & Parasailing",
                    today.plusDays(6),
                    "09:30 AM",
                    "Baga Beach Center",
                    "Adventure",
                    "High-speed jet ski, banana boat ride, and tandem parasailing.",
                    savedTrip
            ));

            itineraryRepository.save(new ItineraryItem(
                    "Dudhsagar Falls Day Trip",
                    today.plusDays(7),
                    "08:00 AM",
                    "Mollem National Park",
                    "Sightseeing",
                    "Jeep safari ride across jungle streams to reach the cascading waterfall pool.",
                    savedTrip
            ));

            itineraryRepository.save(new ItineraryItem(
                    "Souvenir Shopping & Departure Flight",
                    today.plusDays(9),
                    "02:00 PM",
                    "Panjim Market & Airport",
                    "Travel",
                    "Pick up cashew nuts, feni, spices and return rental SUVs at airport.",
                    savedTrip
            ));

            // Expenses
            expenseRepository.save(new Expense(
                    "Beach Resort Villa (4 Nights)",
                    new BigDecimal("14000.00"),
                    "Accommodation",
                    "TripSync Admin",
                    today.plusDays(1),
                    "Includes breakfast buffet for 4 people",
                    savedTrip
            ));

            expenseRepository.save(new Expense(
                    "Two Self-Drive Rental SUVs",
                    new BigDecimal("5200.00"),
                    "Transportation",
                    "Rahul Sharma",
                    today.plusDays(2),
                    "4 days rental + fuel tank full",
                    savedTrip
            ));

            expenseRepository.save(new Expense(
                    "Welcome Seafood Dinner at Britto's",
                    new BigDecimal("3400.00"),
                    "Food",
                    "Pooja Patel",
                    today.plusDays(5),
                    "Group dinner bill with dessert",
                    savedTrip
            ));

            expenseRepository.save(new Expense(
                    "Water Sports Combo Passes",
                    new BigDecimal("4200.00"),
                    "Activities",
                    "Amit Verma",
                    today.plusDays(6),
                    "4 person combo tickets",
                    savedTrip
            ));
        }
    }
}
