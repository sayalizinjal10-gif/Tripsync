package com.tripsync.repository;

import com.tripsync.model.ItineraryItem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface ItineraryItemRepository extends JpaRepository<ItineraryItem, Long> {
    List<ItineraryItem> findByTripIdOrderByActivityDateAscActivityTimeAsc(Long tripId);
    List<ItineraryItem> findByTripIdAndActivityDateOrderByActivityTimeAsc(Long tripId, LocalDate date);
}
