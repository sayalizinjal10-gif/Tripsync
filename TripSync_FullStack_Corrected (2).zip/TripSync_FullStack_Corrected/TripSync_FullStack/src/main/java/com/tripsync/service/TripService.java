package com.tripsync.service;

import com.tripsync.model.Trip;
import com.tripsync.model.TripMember;
import com.tripsync.model.User;
import com.tripsync.repository.TripMemberRepository;
import com.tripsync.repository.TripRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

/**
 * Service managing trip lifecycle, validation, member roster, and search.
 */
@Service
public class TripService {

    private final TripRepository tripRepository;
    private final TripMemberRepository memberRepository;

    public TripService(TripRepository tripRepository, TripMemberRepository memberRepository) {
        this.tripRepository = tripRepository;
        this.memberRepository = memberRepository;
    }

    public List<Trip> getAllTrips() {
        return tripRepository.findAllByOrderByStartDateDesc();
    }

    public List<Trip> getTripsByUser(User user) {
        return tripRepository.findByCreatedByOrderByStartDateDesc(user);
    }

    public List<Trip> searchTrips(String query) {
        if (query == null || query.trim().isEmpty()) {
            return getAllTrips();
        }
        return tripRepository.searchTrips(query.trim());
    }

    public Optional<Trip> getTripById(Long id) {
        return tripRepository.findById(id);
    }

    @Transactional
    public Trip createTrip(Trip trip, User creator) {
        validateTripDates(trip.getStartDate(), trip.getEndDate());

        trip.setCreatedBy(creator);
        Trip savedTrip = tripRepository.save(trip);

        // Automatically add the creator as Organizer member
        if (creator != null) {
            TripMember organizer = new TripMember(
                    creator.getFullName(),
                    creator.getEmail(),
                    "Organizer",
                    savedTrip
            );
            memberRepository.save(organizer);
        }

        return savedTrip;
    }

    @Transactional
    public Trip updateTrip(Long id, Trip updatedTrip) {
        Trip existing = tripRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Trip not found with ID: " + id));

        validateTripDates(updatedTrip.getStartDate(), updatedTrip.getEndDate());

        existing.setName(updatedTrip.getName());
        existing.setDestination(updatedTrip.getDestination());
        existing.setStartDate(updatedTrip.getStartDate());
        existing.setEndDate(updatedTrip.getEndDate());
        existing.setDescription(updatedTrip.getDescription());
        existing.setTravelMode(updatedTrip.getTravelMode());
        existing.setTravelDetails(updatedTrip.getTravelDetails());
        existing.setBudget(updatedTrip.getBudget());
        existing.setStatus(updatedTrip.getStatus());

        return tripRepository.save(existing);
    }

    @Transactional
    public void deleteTrip(Long id) {
        if (!tripRepository.existsById(id)) {
            throw new IllegalArgumentException("Trip not found with ID: " + id);
        }
        tripRepository.deleteById(id);
    }

    @Transactional
    public TripMember addMember(Long tripId, String name, String email, String role) {
        Trip trip = tripRepository.findById(tripId)
                .orElseThrow(() -> new IllegalArgumentException("Trip not found with ID: " + tripId));

        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Member name is required.");
        }

        String cleanName = name.trim();
        if (memberRepository.existsByTripIdAndNameIgnoreCase(tripId, cleanName)) {
            throw new IllegalArgumentException("Member '" + cleanName + "' is already in this trip.");
        }

        TripMember member = new TripMember(
                cleanName,
                email != null ? email.trim() : null,
                role != null && !role.trim().isEmpty() ? role.trim() : "Member",
                trip
        );

        return memberRepository.save(member);
    }

    @Transactional
    public void removeMember(Long tripId, Long memberId) {
        TripMember member = memberRepository.findById(memberId)
                .orElseThrow(() -> new IllegalArgumentException("Member not found with ID: " + memberId));

        if (!member.getTrip().getId().equals(tripId)) {
            throw new IllegalArgumentException("Member does not belong to this trip.");
        }

        memberRepository.delete(member);
    }

    private void validateTripDates(LocalDate start, LocalDate end) {
        if (start == null || end == null) {
            throw new IllegalArgumentException("Trip start and end dates are required.");
        }
        if (end.isBefore(start)) {
            throw new IllegalArgumentException("Trip end date cannot be earlier than start date.");
        }
    }
}
