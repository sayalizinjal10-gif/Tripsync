package com.tripsync.service;

import com.tripsync.dto.ExpenseSummaryDto;
import com.tripsync.dto.MemberBalanceDto;
import com.tripsync.dto.SettlementDto;
import com.tripsync.model.Expense;
import com.tripsync.model.Trip;
import com.tripsync.model.TripMember;
import com.tripsync.repository.ExpenseRepository;
import com.tripsync.repository.TripRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.*;

/**
 * Service managing trip expenses, category breakdowns, fair split calculation,
 * and peer-to-peer debt settlement recommendations.
 */
@Service
public class ExpenseService {

    private final ExpenseRepository expenseRepository;
    private final TripRepository tripRepository;

    public ExpenseService(ExpenseRepository expenseRepository, TripRepository tripRepository) {
        this.expenseRepository = expenseRepository;
        this.tripRepository = tripRepository;
    }

    public List<Expense> getExpensesForTrip(Long tripId) {
        return expenseRepository.findByTripIdOrderByExpenseDateDescIdDesc(tripId);
    }

    @Transactional
    public Expense addExpense(Long tripId, Expense expense) {
        Trip trip = tripRepository.findById(tripId)
                .orElseThrow(() -> new IllegalArgumentException("Trip not found with ID: " + tripId));

        if (expense.getAmount() == null || expense.getAmount().compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Expense amount must be greater than zero.");
        }
        if (expense.getPaidBy() == null || expense.getPaidBy().trim().isEmpty()) {
            throw new IllegalArgumentException("Payer name is required.");
        }
        if (expense.getExpenseDate() == null) {
            expense.setExpenseDate(LocalDate.now());
        }

        expense.setTrip(trip);
        return expenseRepository.save(expense);
    }

    @Transactional
    public void deleteExpense(Long expenseId) {
        expenseRepository.deleteById(expenseId);
    }

    public ExpenseSummaryDto calculateExpenseSummary(Long tripId) {
        Trip trip = tripRepository.findById(tripId)
                .orElseThrow(() -> new IllegalArgumentException("Trip not found with ID: " + tripId));

        List<Expense> expenses = expenseRepository.findByTripIdOrderByExpenseDateDescIdDesc(tripId);

        ExpenseSummaryDto summary = new ExpenseSummaryDto();
        summary.setTripId(trip.getId());
        summary.setTripName(trip.getName());
        summary.setBudget(trip.getBudget() != null ? trip.getBudget() : BigDecimal.ZERO);
        summary.setExpenseCount(expenses.size());

        // 1. Calculate total expenses and category breakdown
        BigDecimal total = BigDecimal.ZERO;
        Map<String, BigDecimal> categoryTotals = new LinkedHashMap<>();

        // Pre-initialize common categories
        categoryTotals.put("Food", BigDecimal.ZERO);
        categoryTotals.put("Accommodation", BigDecimal.ZERO);
        categoryTotals.put("Transportation", BigDecimal.ZERO);
        categoryTotals.put("Activities", BigDecimal.ZERO);
        categoryTotals.put("Other", BigDecimal.ZERO);

        for (Expense exp : expenses) {
            BigDecimal amt = exp.getAmount() != null ? exp.getAmount() : BigDecimal.ZERO;
            total = total.add(amt);

            String cat = exp.getCategory() != null ? exp.getCategory() : "Other";
            categoryTotals.put(cat, categoryTotals.getOrDefault(cat, BigDecimal.ZERO).add(amt));
        }

        summary.setTotalExpense(total);
        summary.setCategoryTotals(categoryTotals);

        // 2. Identify all participating group members
        Set<String> memberNames = new LinkedHashSet<>();
        if (trip.getMembers() != null && !trip.getMembers().isEmpty()) {
            for (TripMember m : trip.getMembers()) {
                if (m.getName() != null && !m.getName().trim().isEmpty()) {
                    memberNames.add(m.getName().trim());
                }
            }
        }
        // Also ensure any member who paid an expense is in the roster
        for (Expense exp : expenses) {
            if (exp.getPaidBy() != null && !exp.getPaidBy().trim().isEmpty()) {
                memberNames.add(exp.getPaidBy().trim());
            }
        }
        if (memberNames.isEmpty()) {
            memberNames.add("Organizer");
        }

        int count = memberNames.size();
        summary.setMemberCount(count);

        // 3. Calculate fair share per person
        BigDecimal equalShare = count > 0
                ? total.divide(BigDecimal.valueOf(count), 2, RoundingMode.HALF_UP)
                : BigDecimal.ZERO;
        summary.setEqualShare(equalShare);

        // 4. Calculate total paid by each member
        Map<String, BigDecimal> paidByMember = new HashMap<>();
        for (String m : memberNames) {
            paidByMember.put(m, BigDecimal.ZERO);
        }
        for (Expense exp : expenses) {
            String payer = exp.getPaidBy() != null ? exp.getPaidBy().trim() : "Unknown";
            paidByMember.put(payer, paidByMember.getOrDefault(payer, BigDecimal.ZERO).add(exp.getAmount()));
        }

        // 5. Compute net balance for each member
        List<MemberBalanceDto> balances = new ArrayList<>();
        Map<String, BigDecimal> netBalances = new HashMap<>();

        for (String member : memberNames) {
            BigDecimal paid = paidByMember.getOrDefault(member, BigDecimal.ZERO);
            BigDecimal net = paid.subtract(equalShare);
            balances.add(new MemberBalanceDto(member, paid, equalShare, net));
            netBalances.put(member, net);
        }
        summary.setMemberBalances(balances);

        // 6. Compute debt settlements (Who owes whom)
        summary.setSettlements(computeSettlements(netBalances));

        return summary;
    }

    /**
     * Greedy algorithm to compute the minimal set of transactions to settle debts.
     */
    private List<SettlementDto> computeSettlements(Map<String, BigDecimal> netBalances) {
        List<SettlementDto> settlements = new ArrayList<>();

        // Debtors (negative balance, owes money)
        PriorityQueue<Map.Entry<String, BigDecimal>> debtors = new PriorityQueue<>(
                Comparator.comparing(Map.Entry::getValue)
        );

        // Creditors (positive balance, gets back money)
        PriorityQueue<Map.Entry<String, BigDecimal>> creditors = new PriorityQueue<>(
                (a, b) -> b.getValue().compareTo(a.getValue())
        );

        for (Map.Entry<String, BigDecimal> entry : netBalances.entrySet()) {
            if (entry.getValue().compareTo(new BigDecimal("-0.01")) < 0) {
                debtors.add(new AbstractMap.SimpleEntry<>(entry.getKey(), entry.getValue()));
            } else if (entry.getValue().compareTo(new BigDecimal("0.01")) > 0) {
                creditors.add(new AbstractMap.SimpleEntry<>(entry.getKey(), entry.getValue()));
            }
        }

        while (!debtors.isEmpty() && !creditors.isEmpty()) {
            Map.Entry<String, BigDecimal> debtor = debtors.poll();
            Map.Entry<String, BigDecimal> creditor = creditors.poll();

            BigDecimal debtorOwes = debtor.getValue().abs();
            BigDecimal creditorGets = creditor.getValue();

            BigDecimal transferAmount = debtorOwes.min(creditorGets).setScale(2, RoundingMode.HALF_UP);

            if (transferAmount.compareTo(BigDecimal.ZERO) > 0) {
                settlements.add(new SettlementDto(debtor.getKey(), creditor.getKey(), transferAmount));
            }

            BigDecimal remainingDebt = debtorOwes.subtract(transferAmount);
            BigDecimal remainingCredit = creditorGets.subtract(transferAmount);

            if (remainingDebt.compareTo(new BigDecimal("0.01")) > 0) {
                debtors.add(new AbstractMap.SimpleEntry<>(debtor.getKey(), remainingDebt.negate()));
            }
            if (remainingCredit.compareTo(new BigDecimal("0.01")) > 0) {
                creditors.add(new AbstractMap.SimpleEntry<>(creditor.getKey(), remainingCredit));
            }
        }

        return settlements;
    }
}
