package com.tripsync.controller;
import com.tripsync.repository.TripRepository; import org.springframework.stereotype.Controller; import org.springframework.ui.Model; import org.springframework.web.bind.annotation.GetMapping;
@Controller public class PageController {
 private final TripRepository trips; public PageController(TripRepository trips){this.trips=trips;}
 @GetMapping("/") public String home(Model model){model.addAttribute("trips",trips.findAll());return "index";}
 @GetMapping("/login") public String login(){return "login";}
}
