package com.tripsync.service;

import com.tripsync.model.Destination;
import com.tripsync.model.Trip;
import com.tripsync.repository.DestinationRepository;
import com.tripsync.repository.TripRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Service managing destination suggestions, notes, and voting.
 */
@Service
public class DestinationService {

    private final DestinationRepository destinationRepository;
    private final TripRepository tripRepository;

    public DestinationService(DestinationRepository destinationRepository, TripRepository tripRepository) {
        this.destinationRepository = destinationRepository;
        this.tripRepository = tripRepository;
    }

    public List<Destination> getDestinationsForTrip(Long tripId) {
        return destinationRepository.findByTripIdOrderByVotesDesc(tripId);
    }

    @Transactional
    public Destination addDestination(Long tripId, Destination destination) {
        Trip trip = tripRepository.findById(tripId)
                .orElseThrow(() -> new IllegalArgumentException("Trip not found with ID: " + tripId));

        destination.setTrip(trip);
        destination.setVotes(0);
        return destinationRepository.save(destination);
    }

    @Transactional
    public Destination voteDestination(Long destinationId) {
        Destination destination = destinationRepository.findById(destinationId)
                .orElseThrow(() -> new IllegalArgumentException("Destination not found with ID: " + destinationId));

        destination.setVotes(destination.getVotes() + 1);
        return destinationRepository.save(destination);
    }

    @Transactional
    public void deleteDestination(Long destinationId) {
        destinationRepository.deleteById(destinationId);
    }
}
