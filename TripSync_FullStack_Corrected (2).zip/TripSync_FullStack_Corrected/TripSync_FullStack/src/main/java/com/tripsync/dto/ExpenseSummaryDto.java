package com.tripsync.dto;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * DTO containing aggregate financial data for a trip:
 * - Total trip expenditure
 * - Budget status
 * - Fair share per member
 * - Breakdown by expense category
 * - Individual member balances
 * - Step-by-step debt settlement recommendations
 */
public class ExpenseSummaryDto {
    private Long tripId;
    private String tripName;
    private BigDecimal totalExpense = BigDecimal.ZERO;
    private BigDecimal budget = BigDecimal.ZERO;
    private BigDecimal equalShare = BigDecimal.ZERO;
    private int memberCount = 1;
    private int expenseCount = 0;
    private Map<String, BigDecimal> categoryTotals = new HashMap<>();
    private List<MemberBalanceDto> memberBalances = new ArrayList<>();
    private List<SettlementDto> settlements = new ArrayList<>();

    public ExpenseSummaryDto() {
    }

    public Long getTripId() {
        return tripId;
    }

    public void setTripId(Long tripId) {
        this.tripId = tripId;
    }

    public String getTripName() {
        return tripName;
    }

    public void setTripName(String tripName) {
        this.tripName = tripName;
    }

    public BigDecimal getTotalExpense() {
        return totalExpense;
    }

    public void setTotalExpense(BigDecimal totalExpense) {
        this.totalExpense = totalExpense;
    }

    public BigDecimal getBudget() {
        return budget;
    }

    public void setBudget(BigDecimal budget) {
        this.budget = budget;
    }

    public BigDecimal getEqualShare() {
        return equalShare;
    }

    public void setEqualShare(BigDecimal equalShare) {
        this.equalShare = equalShare;
    }

    public int getMemberCount() {
        return memberCount;
    }

    public void setMemberCount(int memberCount) {
        this.memberCount = memberCount;
    }

    public int getExpenseCount() {
        return expenseCount;
    }

    public void setExpenseCount(int expenseCount) {
        this.expenseCount = expenseCount;
    }

    public Map<String, BigDecimal> getCategoryTotals() {
        return categoryTotals;
    }

    public void setCategoryTotals(Map<String, BigDecimal> categoryTotals) {
        this.categoryTotals = categoryTotals;
    }

    public List<MemberBalanceDto> getMemberBalances() {
        return memberBalances;
    }

    public void setMemberBalances(List<MemberBalanceDto> memberBalances) {
        this.memberBalances = memberBalances;
    }

    public List<SettlementDto> getSettlements() {
        return settlements;
    }

    public void setSettlements(List<SettlementDto> settlements) {
        this.settlements = settlements;
    }
}
