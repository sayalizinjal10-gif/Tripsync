package com.tripsync.repository;

import com.tripsync.model.TripMember;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TripMemberRepository extends JpaRepository<TripMember, Long> {
    List<TripMember> findByTripIdOrderByNameAsc(Long tripId);
    boolean existsByTripIdAndNameIgnoreCase(Long tripId, String name);
}
