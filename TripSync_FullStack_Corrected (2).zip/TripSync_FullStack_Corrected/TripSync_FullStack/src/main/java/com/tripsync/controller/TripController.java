package com.tripsync.controller;
import com.tripsync.model.*; import com.tripsync.repository.*; import jakarta.validation.Valid;
import org.springframework.http.HttpStatus; import org.springframework.web.bind.annotation.*; import org.springframework.web.server.ResponseStatusException;
import java.math.BigDecimal; import java.math.RoundingMode; import java.util.*;
@RestController @RequestMapping("/api") public class TripController {
 private final TripRepository trips; private final DestinationRepository destinations; private final ItineraryItemRepository itinerary; private final ExpenseRepository expenses;
 public TripController(TripRepository t,DestinationRepository d,ItineraryItemRepository i,ExpenseRepository e){trips=t;destinations=d;itinerary=i;expenses=e;}
 @GetMapping("/trips") public List<Trip> allTrips(){return trips.findAll();}
 @PostMapping("/trips") @ResponseStatus(HttpStatus.CREATED) public Trip createTrip(@Valid @RequestBody Trip t){t.setId(null);if(t.getEndDate().isBefore(t.getStartDate()))throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"End date must not be before start date");return trips.save(t);}
 @GetMapping("/trips/{id}/destinations") public List<Destination> getDestinations(@PathVariable Long id){requireTrip(id);return destinations.findByTripIdOrderByVotesDesc(id);}
 @PostMapping("/trips/{id}/destinations") @ResponseStatus(HttpStatus.CREATED) public Destination addDestination(@PathVariable Long id,@Valid @RequestBody Destination d){d.setId(null);d.setTrip(requireTrip(id));d.setVotes(0);return destinations.save(d);}
 @PostMapping("/destinations/{id}/vote") public Destination vote(@PathVariable Long id){Destination d=destinations.findById(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Destination not found"));d.setVotes(d.getVotes()+1);return destinations.save(d);}
 @GetMapping("/trips/{id}/itinerary") public List<ItineraryItem> getItinerary(@PathVariable Long id){requireTrip(id);return itinerary.findByTripIdOrderByActivityDateAsc(id);}
 @PostMapping("/trips/{id}/itinerary") @ResponseStatus(HttpStatus.CREATED) public ItineraryItem addItinerary(@PathVariable Long id,@Valid @RequestBody ItineraryItem item){item.setId(null);item.setTrip(requireTrip(id));return itinerary.save(item);}
 @GetMapping("/trips/{id}/expenses") public List<Expense> getExpenses(@PathVariable Long id){requireTrip(id);return expenses.findByTripIdOrderByIdDesc(id);}
 @PostMapping("/trips/{id}/expenses") @ResponseStatus(HttpStatus.CREATED) public Expense addExpense(@PathVariable Long id,@Valid @RequestBody Expense item){item.setId(null);item.setTrip(requireTrip(id));return expenses.save(item);}
 @GetMapping("/trips/{id}/summary") public Map<String,Object> summary(@PathVariable Long id){Trip t=requireTrip(id);List<Expense> list=expenses.findByTripIdOrderByIdDesc(id);BigDecimal total=list.stream().map(Expense::getAmount).reduce(BigDecimal.ZERO,BigDecimal::add);Map<String,Object> out=new LinkedHashMap<>();out.put("tripId",id);out.put("members",t.getMembers());out.put("totalExpense",total);out.put("equalShare",total.divide(BigDecimal.valueOf(Math.max(1,t.getMembers())),2,RoundingMode.HALF_UP));out.put("expenseCount",list.size());return out;}
 private Trip requireTrip(Long id){return trips.findById(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Trip not found"));}
}
